package com.example.a726224.game;

import android.os.Bundle;
import android.preference.PreferenceFragment;

/**
 * Created by Steve Silliker march 2017 prototype game
 */

public class SettingsMenu extends PreferenceFragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//
//        // Load the preferences from an XML resource
//        addPreferencesFromResource(R.xml.preferences);

        // started using Eclipse to build code, then pasting it into android studio.
    }


}
