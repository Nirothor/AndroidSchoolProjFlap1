package com.example.a726224.game;

/**
 * Created by 726224 on 3/13/2017.
 */

public class NavAlert // This is going to be where I store the notifications that pop up from my app.
{
}
